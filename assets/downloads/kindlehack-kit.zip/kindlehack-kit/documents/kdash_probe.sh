#!/bin/sh
# Name: 看板 診斷
# Author: kdash
O=/mnt/us/kdash/probe.txt; mkdir -p /mnt/us/kdash
FB=/mnt/us/libkh/bin/fbink; [ -x /var/local/kmc/kindlepw2/bin/fbink ] && FB=/var/local/kmc/kindlepw2/bin/fbink
{
echo "== date"; date; date -u; echo "TZ=$TZ"; cat /etc/localtime 2>/dev/null | tail -c 40; echo
echo "== id"; id; uname -a; cat /etc/prettyversion.txt 2>/dev/null
echo "== fbink $FB"; ls -la /mnt/us/libkh/bin /var/local/kmc/*/bin 2>&1 | head -30
$FB -e 2>&1; $FB -h 2>&1 | head -150
echo "== input"; cat /proc/bus/input/devices
echo "== net"; ifconfig 2>&1 | head -30; cat /etc/resolv.conf
echo "== tools"; for c in curl wget usleep sleep timeout setsid nohup lipc-get-prop lipc-set-prop initctl stop start python python3 sqlite3 telnetd dropbear busybox hexdump od; do printf "%s: " $c; command -v $c || echo no; done
busybox 2>&1 | head -40
echo "== curl"; curl --version 2>&1 | head -3
curl -s -m 20 "https://api.open-meteo.com/v1/forecast?latitude=25.03&longitude=121.52&current=temperature_2m,weather_code,is_day&timezone=Asia%2FTaipei" 2>&1 | head -c 600; echo " rc=$?"
curl -sk -m 20 "https://api.open-meteo.com/v1/forecast?latitude=25.03&longitude=121.52&current=temperature_2m&timezone=Asia%2FTaipei" 2>&1 | head -c 300; echo " rc(-k)=$?"
echo "== power"; lipc-get-prop com.lab126.powerd status 2>&1 | head -20; lipc-get-prop com.lab126.powerd battLevel 2>&1
echo "== jobs"; initctl list 2>&1 | grep -iE 'gui|framework|webreader|pillow|awesome|blanket|cmd|wifi|volumd' 
ls /etc/init.d 2>&1 | head -50
echo "== ps"; ps 2>&1 | head -80
echo "== kmc"; ls -la /var/local/kmc 2>&1; cat /var/local/jailbreak.txt 2>&1
echo "== fonts"; ls /usr/java/lib/fonts 2>&1 | head
} > $O 2>&1
$FB -q -m -y 5 "kdash probe done" 2>/dev/null
