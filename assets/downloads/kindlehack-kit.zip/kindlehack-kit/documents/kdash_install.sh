#!/bin/sh
# Name: 看板 開機自動啟動
# Author: kdash
# 把開機自動啟動設定裝進系統，之後每次開機約 45 秒後自動進看板
FB=/var/local/kmc/kindlepw2/bin/fbink
mntroot rw && cp /mnt/us/kdash/kdash.conf /etc/upstart/kdash.conf; mntroot ro
touch /mnt/us/kdash/AUTOSTART
if [ -f /etc/upstart/kdash.conf ]; then $FB -q -m -y 5 "OK: autostart ON"; else $FB -q -m -y 5 "FAILED: autostart"; fi
