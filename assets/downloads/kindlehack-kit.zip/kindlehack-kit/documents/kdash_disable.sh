#!/bin/sh
# Name: 看板 停用自動啟動
# Author: kdash
# 停用開機自動啟動（重開機後 45 秒內在書庫點這個），並結束正在跑的看板
rm -f /mnt/us/kdash/AUTOSTART
touch /mnt/us/kdash/run/quit
/var/local/kmc/kindlepw2/bin/fbink -q -m -y 5 "autostart OFF"
