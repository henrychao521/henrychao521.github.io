#!/bin/sh
# Name: 看板 啟動
# Author: kdash
cd /mnt/us/kdash || exit 1
if command -v setsid >/dev/null; then setsid sh /mnt/us/kdash/kdash.sh >/dev/null 2>&1 < /dev/null &
else nohup sh /mnt/us/kdash/kdash.sh >/dev/null 2>&1 < /dev/null & fi
