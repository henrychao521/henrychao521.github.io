#!/bin/sh
# Kindle PW3 電子紙看板：時間＋天氣＋JoJo（家裡的貓）動畫；設定可用手機連 http://看板IP 修改（web.sh）。
# 由書庫的「看板 啟動」腳本以背景方式執行；點一下螢幕、5 秒內再點一下就離開並回到原本的 Kindle。
D=/mnt/us/kdash
A=$D/assets
LOG=$D/log.txt
CFG=$D/config.sh
FONT=$D/fonts/NotoTC-Medium.ttf
FONTB=$D/fonts/NotoTC-Black.ttf
FONTP=$D/fonts/NotoTC-Place.ttf; [ -f "$FONTP" ] || FONTP=$FONT   # 地名用：收錄常用繁中字
BIN=/var/local/kmc/kindlepw2/bin
FB=$BIN/fbink; [ -x "$FB" ] || FB=/mnt/us/libkh/bin/fbink
export TZ=CST-8

# 預設值，可在 config.sh 覆寫
LAT=25.03; LON=121.52; PLACE="臺北"; WEATHER_MIN=15; FRAME_US=800000; REMOTE=0
ROTATE=2          # 0 或 2＝橫式（兩個方向），3＝直式（Kindle 原本的方向）
TOUCH_EXIT=0      # 1＝點兩下螢幕可離開；0＝觸控不能離開（只能遠端離開）
FL_DAY=0          # 白天的背光亮度（0＝關，最亮 24）
FL_NIGHT=8        # 晚上（日落到日出）的背光亮度
WEB=1             # 1＝開設定網頁（同一個 Wi-Fi 的手機或電腦連 http://看板IP），只開放同一個網段
[ -f "$CFG" ] && . "$CFG"

RUN=$D/run; mkdir -p "$RUN"
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && mv "$LOG" "$LOG.old"
fb() { "$FB" -q "$@" 2>>"$LOG"; }
pause() { if command -v usleep >/dev/null; then usleep "$1"; else sleep 1; fi; }

# ---------- 版面 ----------
if [ "$ROTATE" = 3 ]; then   # 直式 1072×1448
  SW=1072; SCENE=$A/scene
  Y_DATE=40; X_CLOCK=43; Y_CLOCK=130
  WX_TOP=560; WX_LEFT=0
  ICON_X=70; ICON_Y=580; TEMP_X=300; TEMP_Y=570; TEMP_PX=170
  DESC_X=640; DESC_Y=570; DESC_PX=56; L_X=640; L_Y=650; L_DY=55; L_PX=40
  Y_UPD=830; Y_MSG=890; Y_FC=; Y_SCENE=990
else                         # 橫式 1448×1072
  SW=1448; SCENE=$A/scene_wide
  Y_DATE=24; X_CLOCK=30; Y_CLOCK=105
  WX_TOP=0; WX_LEFT=1030
  ICON_X=1040; ICON_Y=30; TEMP_X=1250; TEMP_Y=40; TEMP_PX=125
  DESC_X=1050; DESC_Y=245; DESC_PX=52; L_X=1050; L_Y=318; L_DY=48; L_PX=34
  Y_UPD=468; Y_MSG=$((Y_DATE+8)); Y_FC=500; Y_SCENE=652
fi
CLOCK_H=380

WD="日一二三四五六"
weekday() { i=$(date +%w); echo "$WD" | cut -c$((i*3+1))-$((i*3+3)); }
MSGS="慢慢來，不用急|喝口水，休息一下|站起來伸展一下|深呼吸，放鬆肩膀|今天也辛苦了|看看遠方，讓眼睛休息"
calm() { n=$(( $(date +%H) % 6 + 1 )); echo "$MSGS" | cut -d'|' -f$n; }

draw_date() {
  txt="$(date +%-m)月$(date +%-d)日　星期$(weekday)"
  if [ "$ROTATE" = 3 ]; then
    fb -b -k top=$Y_DATE,left=0,width=$SW,height=80
    fb -b -m -t regular=$FONT,px=60,top=$Y_DATE "$txt"
  else
    fb -b -k top=$Y_DATE,left=0,width=$WX_LEFT,height=76
    fb -b -t regular=$FONT,px=56,top=$Y_DATE,left=$((X_CLOCK+20)) "$txt"
    fb -b -t regular=$FONT,px=40,top=$Y_MSG,left=470 "$(calm)"   # 提醒句跟日期同一行，一起重畫
  fi
}

cur_ip() { ifconfig wlan0 2>/dev/null | sed -n 's/.*inet addr:\([0-9.]*\).*/\1/p'; }
web_start() {  # 設定網頁（web.sh）：busybox tcpsvd 聽 80 埠，防火牆只放行同一個網段
  [ "$WEB" = 1 ] || return
  ip=$(cur_ip); [ -n "$ip" ] || return
  net=${WEB_NET:-${REMOTE_NET:-${ip%.*}.0/24}}
  iptables -D INPUT -p tcp -s $net --dport 80 -j ACCEPT 2>/dev/null
  iptables -I INPUT -p tcp -s $net --dport 80 -j ACCEPT 2>>"$LOG"
  netstat -ltn 2>/dev/null | grep -q ':80 ' && return
  setsid tcpsvd -c 4 0.0.0.0 80 sh $D/web.sh </dev/null >/dev/null 2>>"$LOG" &
  log "設定網頁開啟 http://$ip（只限 $net）"
}
web_stop() {
  for p in $(ps -ef | awk '/[t]cpsvd .* 80 sh/ {print $2}'); do kill $p 2>/dev/null; done
  iptables -S INPUT 2>/dev/null | grep -- '--dport 80 ' | sed 's/^-A /-D /' | while read -r r; do iptables $r 2>/dev/null; done
}

draw_batt() {  # 右上角：設定網址（IP）＋小電池＋百分比；充電中加註
  ip=$(cur_ip); [ -n "$ip" ] && echo "$ip" > $D/ip.txt
  [ "$ROTATE" = 3 ] && return
  # 文字靠右對齊到電量左邊：中文字約 22 px、英數字約 12 px 寬
  if [ -z "$ip" ]; then t2="Wi-Fi 未連線"; tw=$((6 * 12 + 3 * 22))
  elif [ "$WEB" = 1 ]; then t2="設定 http://$ip"; tw=$((2 * 22 + (8 + ${#ip}) * 12))
  else t2="$ip"; tw=$((${#ip} * 12)); fi
  fb -b -k top=0,left=900,width=330,height=34
  fb -b -t regular=$FONT,px=22,top=2,left=$((1222 - tw)) "$t2"
  lv=$(lipc-get-prop com.lab126.powerd battLevel 2>/dev/null); lv=${lv:-0}
  ch=$(lipc-get-prop com.lab126.powerd isCharging 2>/dev/null)
  bx=1380; by=8
  fb -b -k top=0,left=1230,width=$((SW-1230)),height=38
  fb -b -k top=$by,left=$bx,width=50,height=24 -B BLACK
  fb -b -k top=$((by+3)),left=$((bx+3)),width=44,height=18
  fb -b -k top=$((by+7)),left=$((bx+50)),width=5,height=10 -B BLACK
  fw=$((40*lv/100)); [ $fw -gt 0 ] && fb -b -k top=$((by+5)),left=$((bx+5)),width=$fw,height=14 -B BLACK
  if [ "$ch" = 1 ]; then t="充電中 $lv%"; tl=$((bx-140)); else t="$lv%"; tl=$((bx-64)); fi
  fb -b -t regular=$FONT,px=24,top=$((by-1)),left=$tl "$t"
}

draw_clock() {
  hm=$(date +%H%M)
  h1=$(echo $hm | cut -c1); h2=$(echo $hm | cut -c2); m1=$(echo $hm | cut -c3); m2=$(echo $hm | cut -c4)
  [ "$h1" = 0 ] && h1=blank
  x=$X_CLOCK
  for p in $h1 $h2 colon $m1 $m2; do
    fb -b -g file=$A/digits/$p.png,x=$x,y=$Y_CLOCK
    if [ $p = colon ]; then x=$((x+70+12)); else x=$((x+220+12)); fi
  done
}

# ---------- 對時：完全沒電後硬體時鐘可能歸零，開機後自己對時並寫回硬體時鐘 ----------
sync_time() {
  if timeout 20 ntpdate -s pool.ntp.org 2>>"$LOG" || timeout 20 ntpdate -s time.google.com 2>>"$LOG"; then :
  else  # 退路：讀 HTTPS 回應標頭的 Date（時間錯太多時憑證會失敗，所以加 -k）
    hd=$(curl -skI -m 20 https://api.open-meteo.com/ 2>/dev/null | sed -n 's/^[Dd]ate: *//p' | tr -d '\r')
    [ -n "$hd" ] && date -s "$hd" >/dev/null 2>>"$LOG" || return 1
  fi
  hwclock -w -u 2>>"$LOG"
  date +%s > $RUN/time.ok; log "對時完成 $(date '+%Y-%m-%d %H:%M:%S')"
}

# ---------- 天氣 ----------
WX=$RUN/wx.json
fetch_weather() {
  url="https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FTaipei&forecast_days=4"
  ( curl -s -m 30 "$url" -o $WX.tmp || curl -sk -m 30 "$url" -o $WX.tmp ) 2>>"$LOG"
  if grep -q '"current"' $WX.tmp 2>/dev/null; then mv $WX.tmp $WX; date +%H:%M > $RUN/wx.time; touch $RUN/wx.new
  else log "天氣抓取失敗：$(head -c 200 $WX.tmp 2>/dev/null)"; fi
}
jnum() { # $1=區塊 current/daily  $2=欄位
  sed -n "s/.*\"$1\":{\([^}]*\)}.*/\1/p" $WX | sed -n "s/.*\"$2\":\[\{0,1\}\([-0-9.]*\).*/\1/p"
}
wx_kind() { # WMO 天氣代碼 → 動畫種類|中文（白天晚上另外由日出日落決定）
  c=$1
  case $c in
    0) echo "clear|晴" ;;
    1) echo "partly|晴時多雲" ;;
    2) echo "partly|多雲" ;;
    3) echo "cloudy|陰" ;;
    45|48) echo "fog|霧" ;;
    51|53|55|56|57) echo "drizzle|毛毛雨" ;;
    61) echo "drizzle|小雨" ;; 63) echo "rain|中雨" ;; 65) echo "heavy|大雨" ;;
    66) echo "drizzle|凍雨" ;; 67) echo "rain|凍雨" ;;
    80) echo "drizzle|小陣雨" ;; 81) echo "rain|陣雨" ;; 82) echo "heavy|大陣雨" ;;
    71|73|75|77|85|86) echo "snow|雪" ;;
    95|96|99) echo "thunder|雷雨" ;;
    *) echo "cloudy|—" ;;
  esac
}
jarr() { # $1=欄位 $2=第幾天（1＝今天）
  sed -n 's/.*"daily":{\(.*\)}.*/\1/p' $WX | sed -n "s/.*\"$1\":\[\([^]]*\)\].*/\1/p" | cut -d, -f$2 | tr -d '"'
}
draw_forecast() {  # 未來三天：每格 icon＋星期＋天氣＋高低溫＋降雨
  [ -n "$Y_FC" ] || return
  fb -b -k top=$Y_FC,left=0,width=$SW,height=$((Y_SCENE-Y_FC))
  [ -s $WX ] || return
  w0=$(date +%w); cw=$((SW/3))
  for i in 1 2 3; do
    x=$(( (i-1)*cw + 30 )); c=$(jarr weather_code $((i+1)))
    kd=$(wx_kind "$c"); k=${kd%%|*}; dsc=${kd#*|}
    wd=$(echo "$WD" | cut -c$(( ((w0+i)%7)*3+1 ))-$(( ((w0+i)%7)*3+3 )))
    [ $i = 1 ] && lbl="明天" || lbl="週$wd"
    fb -b -g file=$A/icons/$k.png,x=$x,y=$((Y_FC+12)),w=120,h=120
    fb -b -t regular=$FONTB,px=34,top=$((Y_FC+6)),left=$((x+135)) "$lbl　$dsc"
    fb -b -t regular=$FONT,px=32,top=$((Y_FC+52)),left=$((x+135)) "$(r $(jarr temperature_2m_max $((i+1))))° / $(r $(jarr temperature_2m_min $((i+1))))°"
    fb -b -t regular=$FONT,px=30,top=$((Y_FC+96)),left=$((x+135)) "降雨 $(jarr precipitation_probability_max $((i+1)))%"
  done
}
r() { printf "%.0f" "$1" 2>/dev/null || echo "$1"; }

# ---------- 真實時間：日出日落決定白天／晚上（背光、場景），太陽與月亮的位置 ----------
# 日出日落來自天氣資料，沒有當天資料時以 06:00／17:30 估。run/test_hm 可假裝現在幾點（測試用）。
FL_NOW=; SFX=; SFX_DRAWN=
now_hm() { cat $RUN/test_hm 2>/dev/null || date +%H%M; }
is_night() {
  sr=$(jarr sunrise 1 2>/dev/null); ss=$(jarr sunset 1 2>/dev/null)
  case "$sr" in "$(date +%Y-%m-%d)"*) sr=$(echo "$sr" | cut -c12-16 | tr -d :); ss=$(echo "$ss" | cut -c12-16 | tr -d :) ;;
    *) sr=0600; ss=1730 ;; esac
  nh=$(now_hm)
  [ "$nh" -lt "$sr" ] || [ "$nh" -ge "$ss" ]
}
hm2m() { echo $(( $(expr "${1%??}" + 0) * 60 + $(expr "${1#??}" + 0) )); }
arc_xy() { # $1＝走了多少（0～1000） $2＝圖的半寬：由左（東）到右（西）畫一道弧
  SKY_X=$(( 80 + $1 * (SW - 160) / 1000 - $2 ))
  d=$(( ($1 * 2 - 1000) / 10 ))
  SKY_Y=$(( Y_SCENE + 5 + 110 * d * d / 10000 ))
}
sky_update() {  # 只有晴、晴時多雲看得到日月；陰天、下雨被雲遮住
  SKY=
  case $KIND in clear*|partly*) ;; *) return ;; esac
  m=$(hm2m "$(now_hm)")
  if [ -z "$SFX" ]; then
    a=$(hm2m "$sr"); b=$(hm2m "$ss"); [ "$b" -gt "$a" ] || return
    p=$(( (m - a) * 1000 / (b - a) )); [ "$p" -lt 0 ] && p=0; [ "$p" -gt 1000 ] && p=1000
    SKY=sun; arc_xy "$p" 70
  else
    # 月相：距已知新月（2000-01-06 18:14 UTC）的時間除以朔望月 29.53 天
    ph=$(( ($(date +%s) - 947182440) % 2551443 / 2552 ))
    # 月亮過中天的時間隨月相每天晚約 50 分；前後約 6.2 小時在地平線上，其餘時間沒升起就不畫
    tr=$(( (720 + 1440 * ph / 1000) % 1440 )); d=$(( (m - tr + 2160) % 1440 - 720 ))
    if [ "$d" -ge -372 ] && [ "$d" -le 372 ]; then
      SKY=$A/sky/moon_$(( ((ph + 62) / 125) % 8 )).png; arc_xy $(( (d + 372) * 1000 / 744 )) 60
    fi
  fi
}
time_update() {  # 每分鐘：背光、日夜切換、日月位置
  if is_night; then flv=$FL_NIGHT; SFX=_n; else flv=$FL_DAY; SFX=; fi
  if [ "$flv" != "$FL_NOW" ]; then
    lipc-set-prop com.lab126.powerd flIntensity "$flv" 2>>"$LOG" || \
      echo $((flv * 4095 / 24)) > /sys/class/backlight/max77696-bl/brightness 2>>"$LOG"
    FL_NOW=$flv; log "背光 $flv"
  fi
  if [ "$SFX" != "$SFX_DRAWN" ] && [ -s $WX ]; then log "日夜切換：$SFX"; draw_weather; refresh_weather; fi
  sky_update
}
draw_scene() {  # 有日月的天氣：先清空、畫日月，再疊上天空透明的場景，雲和貓才會擋住日月
  f=$SCENE/$KIND/$(printf %02d $n).png
  [ -f $f ] || { n=0; f=$SCENE/$KIND/00.png; }   # 每種天氣的格數不同，播完從頭
  case $KIND in clear*|partly*)
    fb -b -k top=$Y_SCENE,left=0,width=$SW,height=420
    if [ "$SKY" = sun ]; then fb -b -g file=$A/sky/sun_$(( n / 3 % 4 )).png,x=$SKY_X,y=$SKY_Y
    elif [ -n "$SKY" ]; then fb -b -g file=$SKY,x=$SKY_X,y=$SKY_Y; fi ;;
  esac
  fb -g file=$f,x=0,y=$Y_SCENE -W A2
}
KIND=cloudy
draw_weather() {
  fb -b -k top=$WX_TOP,left=$WX_LEFT,width=$((SW-WX_LEFT)),height=$((Y_UPD-WX_TOP))
  [ "$ROTATE" = 3 ] && fb -b -k top=$Y_UPD,left=0,width=$SW,height=$((Y_SCENE-Y_UPD))
  if [ ! -s $WX ]; then
    fb -b -t regular=$FONT,px=44,top=$DESC_Y,left=$DESC_X "天氣資料讀取中…"
    return
  fi
  t=$(jnum current temperature_2m); rh=$(jnum current relative_humidity_2m); fl=$(jnum current apparent_temperature)
  code=$(cat $RUN/test_code 2>/dev/null || jnum current weather_code)   # test_code：測試用
  tmax=$(jnum daily temperature_2m_max); tmin=$(jnum daily temperature_2m_min); pop=$(jnum daily precipitation_probability_max)
  is_night && SFX=_n || SFX=; SFX_DRAWN=$SFX
  kd=$(wx_kind "$code"); BASE=${kd%%|*}; desc=${kd#*|}
  [ -d $SCENE/$BASE ] || BASE=cloudy
  KIND=$BASE$SFX
  ic=$A/icons/$KIND.png; [ -f $ic ] || ic=$A/icons/$BASE.png
  fb -b -g file=$ic,x=$ICON_X,y=$ICON_Y
  fb -b -t regular=$FONTB,px=$TEMP_PX,top=$TEMP_Y,left=$TEMP_X "$(r $t)°"
  fb -b -t regular=$FONT,px=$DESC_PX,top=$DESC_Y,left=$DESC_X "$desc"
  fb -b -t regular=$FONT,px=$L_PX,top=$L_Y,left=$L_X "體感 $(r $fl)°　濕度 $rh%"
  fb -b -t regular=$FONT,px=$L_PX,top=$((L_Y+L_DY)),left=$L_X "最高 $(r $tmax)°　最低 $(r $tmin)°"
  fb -b -t regular=$FONT,px=$L_PX,top=$((L_Y+2*L_DY)),left=$L_X "降雨機率 $pop%"
  if [ "$ROTATE" = 3 ]; then
    ipt=$(cat $D/ip.txt 2>/dev/null); [ "$WEB" = 1 ] && [ -n "$ipt" ] && ipt="設定 http://$ipt"
    fb -b -m -t regular=$FONTP,px=30,top=$Y_UPD "$PLACE　天氣更新於 $(cat $RUN/wx.time 2>/dev/null)　$ipt"
    fb -b -m -t regular=$FONT,px=42,top=$Y_MSG "$(calm)"
  else
    fb -b -t regular=$FONTP,px=24,top=$Y_UPD,left=$L_X "$PLACE　更新 $(cat $RUN/wx.time 2>/dev/null)"
  fi
  draw_forecast
  draw_batt   # 天氣區清除時會蓋掉右上角，重畫電池
}
refresh_weather() {
  fb -s top=$WX_TOP,left=$WX_LEFT,width=$((SW-WX_LEFT)),height=$((Y_UPD-WX_TOP)) -W GC16
  fb -s top=$Y_UPD,left=0,width=$SW,height=$((Y_SCENE-Y_UPD)) -W GC16
  fb -s top=0,left=0,width=$WX_LEFT,height=100 -W GC16
}

full_redraw() {
  fb -b -k
  draw_date; draw_clock; draw_weather
  fb -s -f -W GC16
}

# ---------- 觸控：點一下提示、5 秒內再點一下離開 ----------
touch_dev() {
  awk '/^N:/{n=tolower($0)} /^H:/{ if (n ~ /touch|cyttsp|zforce|pt_mt|elan|cypress/ && match($0, /event[0-9]+/)) print "/dev/input/" substr($0, RSTART, RLENGTH) }' /proc/bus/input/devices | head -1
}
watch_touch() {
  T=$(touch_dev); [ -z "$T" ] && { log "找不到觸控裝置"; return; }
  log "觸控裝置 $T"
  while true; do
    dd if=$T bs=16 count=1 >/dev/null 2>&1
    touch $RUN/tap1; sleep 1
    rm -f $RUN/tap2
    ( dd if=$T bs=16 count=1 >/dev/null 2>&1; touch $RUN/tap2 ) & P=$!
    sleep 5; kill $P 2>/dev/null
    if [ -f $RUN/tap2 ]; then touch $RUN/quit; return; fi
    touch $RUN/tapcancel
  done
}
kill_helpers() {  # 收掉背景的觸控監聽（含卡在 dd 的子行程）
  for p in $(ps -ef | awk -v me=$$ '($0 ~ /[k]dash\.sh/ && $2 != me) || $0 ~ /[d]d if=\/dev\/input/ {print $2}'); do kill $p 2>/dev/null; done
}

# ---------- 啟動與結束 ----------
cleanup() {
  log "離開看板"
  kill_helpers
  rm -f $RUN/pid
  if [ -f $RUN/norestore ]; then rm -f $RUN/norestore; exit 0; fi   # 遠端重啟：不回原介面（設定網頁也留著）
  web_stop
  [ -n "$FL_ORIG" ] && lipc-set-prop com.lab126.powerd flIntensity "$FL_ORIG" 2>/dev/null   # 背光還原
  lipc-set-prop com.lab126.powerd preventScreenSaver 0 2>/dev/null
  "$BIN/fbdepth" -r 3 >/dev/null 2>&1
  fb -k -f -W GC16
  start lab126_gui 2>/dev/null || /etc/init.d/framework start 2>/dev/null
  exit 0
}

[ -f $RUN/pid ] && kill -0 "$(cat $RUN/pid)" 2>/dev/null && { log "已在執行"; exit 0; }
echo $$ > $RUN/pid
rm -f $RUN/norestore $RUN/quit $RUN/tap1 $RUN/tap2 $RUN/tapcancel $RUN/wx.new $RUN/reload $RUN/fetch
kill_helpers
trap cleanup INT TERM
log "看板啟動（fbink=$FB，方向 $ROTATE）"
lipc-set-prop com.lab126.powerd preventScreenSaver 1 2>>"$LOG"
FL_ORIG=$(lipc-get-prop com.lab126.powerd flIntensity 2>/dev/null)
stop lab126_gui 2>>"$LOG" || /etc/init.d/framework stop 2>>"$LOG"
sleep 3
"$BIN/fbdepth" -r "$ROTATE" >/dev/null 2>>"$LOG"

sh $D/remote.sh >> "$LOG" 2>&1
web_start
rm -f $RUN/time.ok
sync_time
fetch_weather
full_redraw
time_update
[ "$TOUCH_EXIT" = 1 ] && watch_touch &

n=0; last_min=$(date +%H%M); last_wx=$(date +%s); last_full=$(date +%s); prev=$last_full; last_try=
while true; do
  now=$(date +%s)
  if [ $((now - prev)) -gt 15 ]; then  # 休眠喚醒後（例如按了電源鍵）整頁重畫、補抓天氣
    log "偵測到中斷 $((now - prev)) 秒，重畫"; fetch_weather & sleep 3; full_redraw; last_full=$now; last_min=$(date +%H%M)
  fi
  prev=$now
  [ -f $RUN/quit ] && cleanup
  if [ -f $RUN/tap1 ]; then
    rm -f $RUN/tap1
    fb -k top=$Y_UPD,left=0,width=$SW,height=$((Y_SCENE-Y_UPD)) -W DU
    fb -m -t regular=$FONT,px=40,top=$Y_UPD "5 秒內再點一下螢幕：離開看板" -W DU
  fi
  if [ -f $RUN/tapcancel ]; then rm -f $RUN/tapcancel; draw_weather; refresh_weather; fi

  draw_scene
  n=$((n + 1))

  now=$(date +%s); hm=$(date +%H%M)
  if [ "$hm" != "$last_min" ]; then
    last_min=$hm
    time_update
    if [ $((now - last_full)) -ge 1800 ] || [ "$hm" = 0000 ]; then
      full_redraw; last_full=$now
    else
      draw_clock; draw_date; draw_batt
      fb -s top=0,left=900,width=$((SW-900)),height=38 -W GL16
      fb -s top=$Y_DATE,left=0,width=$((X_CLOCK+996)),height=$((Y_CLOCK+CLOCK_H-Y_DATE+10)) -W GL16
    fi
  fi
  # 還沒對到時間或還沒有天氣（剛開機、Wi-Fi 未連上）：每分鐘重試；對到後每 6 小時校正
  if [ "$hm" != "$last_try" ]; then
    last_try=$hm
    age=$((now - $(cat $RUN/time.ok 2>/dev/null || echo 0)))
    if [ ! -f $RUN/time.ok ] || [ $age -ge 21600 ] || [ $age -lt 0 ] || [ "$(date +%Y)" -lt 2025 ]; then sync_time && full_redraw; fi
    [ -s $WX ] || fetch_weather
  fi
  if [ $((now - last_wx)) -ge $((WEATHER_MIN*60)) ]; then last_wx=$now; fetch_weather & sh $D/remote.sh >> "$LOG" 2>&1 & web_start; fi
  if [ -f $RUN/reload ]; then   # 設定網頁存檔後：重讀設定、重抓天氣、整頁重畫
    rm -f $RUN/reload; . "$CFG"; log "重新載入設定（$PLACE）"
    FL_NOW=; fetch_weather; last_wx=$now; full_redraw; last_full=$now; time_update
  fi
  if [ -f $RUN/fetch ]; then rm -f $RUN/fetch; last_wx=$now; fetch_weather & fi
  if [ -f $RUN/wx.new ]; then rm -f $RUN/wx.new; draw_weather; refresh_weather; time_update; fi
  pause $FRAME_US
done
