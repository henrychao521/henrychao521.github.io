#!/bin/sh
# 看板設定網頁：由 kdash.sh 用 busybox tcpsvd 在 80 埠啟動，每個連線執行一次（stdin/stdout 就是連線）。
# 只接受固定幾個設定值，每個值先檢查格式再寫進 config.sh；不提供任何執行指令的功能。
D=/mnt/us/kdash; RUN=$D/run; CFG=$D/config.sh; WWW=$D/www

reply() {  # $1＝狀態 $2＝類型；內容從 stdin 來
  b=$(cat)
  printf 'HTTP/1.0 %s\r\nContent-Type: %s\r\nContent-Length: %s\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n' \
    "$1" "$2" "$(printf %s "$b" | wc -c)"
  printf %s "$b"
  exit 0
}
json() { reply "${2:-200 OK}" "application/json; charset=utf-8" <<EOF
$1
EOF
}

# ---------- 讀請求 ----------
read -r -t 5 line || exit 0
line=$(printf %s "$line" | tr -d '\r')
method=${line%% *}; path=${line#* }; path=${path%% *}; path=${path%%\?*}
len=0
while read -r -t 5 h; do
  h=$(printf %s "$h" | tr -d '\r'); [ -z "$h" ] && break
  case $h in [Cc]ontent-[Ll]ength:*) len=$(printf %s "${h#*:}" | tr -dc 0-9) ;; esac
done
[ -n "$len" ] || len=0; [ "$len" -gt 4096 ] && len=4096
body=; [ "$method" = POST ] && [ "$len" -gt 0 ] && body=$(head -c "$len")

field() {  # 取表單欄位並做網址解碼
  v=$(printf %s "$body" | tr '&' '\n' | sed -n "s/^$1=//p" | head -1)
  v=$(printf %s "$v" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')
  printf '%b' "$v"
}
num_in() {  # $1 值 $2 最小 $3 最大：整數或最多 6 位小數
  printf %s "$1" | grep -Eq '^-?[0-9]{1,3}(\.[0-9]{1,6})?$' || return 1
  awk -v v="$1" -v a="$2" -v b="$3" 'BEGIN{exit !(v+0>=a && v+0<=b)}'
}

# ---------- 路由 ----------
case "$method $path" in
"GET /"|"GET /index.html")
  reply "200 OK" "text/html; charset=utf-8" < $WWW/index.html ;;

"GET /status.json")
  . $CFG
  ip=$(cat $D/ip.txt 2>/dev/null)
  lv=$(lipc-get-prop com.lab126.powerd battLevel 2>/dev/null); ch=$(lipc-get-prop com.lab126.powerd isCharging 2>/dev/null)
  sr=$(sed -n 's/.*"sunrise":\["[0-9-]*T\([0-9:]*\)".*/\1/p' $RUN/wx.json 2>/dev/null)
  ss=$(sed -n 's/.*"sunset":\["[0-9-]*T\([0-9:]*\)".*/\1/p' $RUN/wx.json 2>/dev/null)
  json "{\"LAT\":\"$LAT\",\"LON\":\"$LON\",\"PLACE\":\"$PLACE\",\"FL_DAY\":\"$FL_DAY\",\"FL_NIGHT\":\"$FL_NIGHT\",\"ROTATE\":\"$ROTATE\",\"WEATHER_MIN\":\"$WEATHER_MIN\",\"FRAME_US\":\"$FRAME_US\",\"TOUCH_EXIT\":\"$TOUCH_EXIT\",\"ip\":\"$ip\",\"battery\":\"${lv:-?}\",\"charging\":\"${ch:-0}\",\"updated\":\"$(cat $RUN/wx.time 2>/dev/null)\",\"sunrise\":\"$sr\",\"sunset\":\"$ss\",\"now\":\"$(date '+%Y-%m-%d %H:%M')\"}" ;;

"POST /refresh")
  touch $RUN/fetch
  json '{"ok":true,"msg":"已要求看板重新抓天氣，約 10 秒後更新"}' ;;

"POST /save")
  . $CFG; old_rot=$ROTATE; err=
  lat=$(field LAT); lon=$(field LON); fld=$(field FL_DAY); fln=$(field FL_NIGHT)
  rot=$(field ROTATE); wmin=$(field WEATHER_MIN); fus=$(field FRAME_US); tex=$(field TOUCH_EXIT)
  # 地名：去掉控制字元與會破壞設定檔的符號，最多 30 位元組（約 10 個中文字）
  place=$(field PLACE | tr -d '\000-\037"$`\\|&;<>'"'" | sed 's/^ *//; s/ *$//')
  num_in "$lat" -90 90 || err="$err 緯度"
  num_in "$lon" -180 180 || err="$err 經度"
  [ -n "$place" ] && [ "$(printf %s "$place" | wc -c)" -le 30 ] || err="$err 地名（1～10 個字）"
  for v in "$fld" "$fln"; do case $v in [0-9]|1[0-9]|2[0-4]) ;; *) err="$err 背光（0～24）" ;; esac; done
  case $rot in 0|2|3) ;; *) err="$err 方向" ;; esac
  case $wmin in 10|15|30|60) ;; *) err="$err 天氣更新間隔" ;; esac
  case $fus in 500000|800000|1200000) ;; *) err="$err 動畫速度" ;; esac
  case $tex in 0|1) ;; *) err="$err 點螢幕離開" ;; esac
  [ -n "$err" ] && json "{\"ok\":false,\"msg\":\"這些欄位不正確：$err\"}" "400 Bad Request"

  tmp=$CFG.web; cp $CFG $tmp
  setkv() {
    if grep -q "^$1=" $tmp; then
      if [ "$1" = PLACE ]; then sed -i "/^PLACE=\"/ s|^PLACE=\"[^\"]*\"|PLACE=\"$2\"|; /^PLACE=[^\"]/ s|^PLACE=[^ #]*|PLACE=\"$2\"|" $tmp
      else sed -i "s|^$1=[^ #]*|$1=$2|" $tmp; fi
    elif [ "$1" = PLACE ]; then echo "PLACE=\"$2\"" >> $tmp
    else echo "$1=$2" >> $tmp; fi
  }
  setkv LAT "$lat"; setkv LON "$lon"; setkv PLACE "$place"; setkv FL_DAY "$fld"; setkv FL_NIGHT "$fln"
  setkv ROTATE "$rot"; setkv WEATHER_MIN "$wmin"; setkv FRAME_US "$fus"; setkv TOUCH_EXIT "$tex"
  sh -n $tmp 2>/dev/null || { rm -f $tmp; json '{"ok":false,"msg":"設定檔檢查失敗，沒有寫入"}' "500 Internal Server Error"; }
  cp $CFG $CFG.bak; mv $tmp $CFG; sync
  echo "$(date '+%m-%d %H:%M:%S') 網頁修改設定（${TCPREMOTEIP:-?}）" >> $D/log.txt
  if [ "$rot" != "$old_rot" ]; then   # 換方向要整個重啟看板
    ( sleep 1; touch $RUN/norestore $RUN/quit; sleep 8; sh /mnt/us/documents/kdash_start.sh ) </dev/null >/dev/null 2>&1 &
    json '{"ok":true,"msg":"已儲存。畫面方向改變，看板重新啟動中（約 30 秒）"}'
  fi
  touch $RUN/reload
  json '{"ok":true,"msg":"已儲存，看板約 10 秒內套用"}' ;;

*)
  reply "404 Not Found" "text/plain; charset=utf-8" <<EOF
找不到這個頁面
EOF
  ;;
esac
